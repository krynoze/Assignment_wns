
var xhr = new XMLHttpRequest();
var apiData = [];
var chartData = {};
xhr.addEventListener('load', function() {
  if (this.status == 200) {
    var response = JSON.parse(this.responseText);
    var characters = response.results;
    characters.forEach(function(character) {
        apiData.push([character.name, parseInt(character.height)]);
    });
    chartData = {
      type: 'line',
      title: {
        text: 'Graph Using External API',
        adjustLayout: 'true'
      },
      scaleX: {
        item: {
          angle: '40'
        }
      },
      plotarea: {
        margin: 'dynamic'
      },
      series: [
        {
          values: apiData
        }
      ]
    };
    zingchart.render({
        id: 'chartOne',
        data: chartData,
        height: '100%',
        width: '100%',
    });
  }
});
xhr.open('GET', 'https://swapi.co/api/people/');
xhr.send();

function sortData() {
  var newData = apiData;
  newData.sort((a,b) => a[1] - b[1]);
  chartData.series[0].values = newData;
  zingchart.render({
    id: 'chartOne',
    data: chartData,
    height: '100%',
    width: '100%',
  });
}
