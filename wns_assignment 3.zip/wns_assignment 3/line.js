const data = [7, 9, 15, 14, 18, 21, 25, 26, 23, 18, 13, 9];
const categories = ['Ram', 'Shyam', 'Raj', 'Yash', 'Jay', 'Jaya', 'Gaurav', 'Dimple', 'Shreya', 'Raghav', 'Akash', 'Keerti'];

var linechart = function(container,charttype,titletext,subtitle){
  Highcharts.chart(container, {
    chart: {
      type: charttype
    },
    credits:false,
    title: {
      text: titletext
    },
    subtitle: {
      text: subtitle
    },
    xAxis: {
      categories,
    },
    yAxis: {
      title: {
        text: 'Marks'
      }
    },
    plotOptions: {
      line: {
        dataLabels: {
          enabled: true
        },
        enableMouseTracking: false
      }
    },
    series: [{
      name: 'Students',
      data,
    }],
  })
}
